import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

const String baseUrl =
    "http://10.0.2.2/flutter_booking_66710991/php_api/";

class GameBookingPage extends StatefulWidget {
  final dynamic game;
  final String name;

  const GameBookingPage({
    super.key,
    required this.game,
    required this.name, required room,
  });

  @override
  State<GameBookingPage> createState() => _GameBookingPageState();
}

class _GameBookingPageState extends State<GameBookingPage> {
  DateTime? selectedDate;
  TimeOfDay? startTime;
  TimeOfDay? endTime;

  bool isLoading = false;

  ////////////////////////////////////////////////////////////
  // 📅 PICK DATE
  ////////////////////////////////////////////////////////////
  Future pickDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2030),
    );

    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  ////////////////////////////////////////////////////////////
  // ⏰ PICK TIME
  ////////////////////////////////////////////////////////////
  Future pickStartTime() async {
    TimeOfDay? picked =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());

    if (picked != null) {
      setState(() => startTime = picked);
    }
  }

  Future pickEndTime() async {
    TimeOfDay? picked =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());

    if (picked != null) {
      setState(() => endTime = picked);
    }
  }

  ////////////////////////////////////////////////////////////
  // 🚀 BOOK GAME
  ////////////////////////////////////////////////////////////
  Future bookGame() async {
    if (selectedDate == null ||
        startTime == null ||
        endTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("กรุณาเลือกวันและเวลา")),
      );
      return;
    }

    setState(() => isLoading = true);

    var response = await http.post(
      Uri.parse("${baseUrl}booking_game.php"),
      body: {
        "username": widget.name,
        "game_id": widget.game['ID'].toString(),
        "date": selectedDate.toString().split(" ")[0],
        "start_time": startTime!.format(context),
        "end_time": endTime!.format(context),
      },
    );

    var data = json.decode(response.body);

    setState(() => isLoading = false);

    if (data["status"] == "success") {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("จองสำเร็จ")),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("จองไม่สำเร็จ")),
      );
    }
  }

  ////////////////////////////////////////////////////////////
  // 🎨 UI
  ////////////////////////////////////////////////////////////
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF5F7),

      appBar: AppBar(
        title: Text(widget.game['NAME']),
        backgroundColor: const Color(0xFFFF6F91),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            /// 🎲 GAME NAME
            Text(
              widget.game['NAME'],
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            /// 📅 DATE
            ElevatedButton(
              onPressed: pickDate,
              child: Text(selectedDate == null
                  ? "เลือกวันที่"
                  : selectedDate.toString().split(" ")[0]),
            ),

            const SizedBox(height: 10),

            /// ⏰ START
            ElevatedButton(
              onPressed: pickStartTime,
              child: Text(startTime == null
                  ? "เลือกเวลาเริ่ม"
                  : startTime!.format(context)),
            ),

            const SizedBox(height: 10),

            /// ⏰ END
            ElevatedButton(
              onPressed: pickEndTime,
              child: Text(endTime == null
                  ? "เลือกเวลาสิ้นสุด"
                  : endTime!.format(context)),
            ),

            const SizedBox(height: 30),

            /// 🔘 BOOK BUTTON
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: isLoading ? null : bookGame,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF6F91),
                ),
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("ยืนยันการจอง"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}